> 本MOD全方位提升玩家能力，涉及升级经验、攻击速度、耐力消耗、格挡时间窗口、背包容量、物品修复、弓箭准星七个方面。欢迎大家试用。
> This MOD improves the player's ability in all aspects, including upgrade experience, attack speed, stamina consumption, blocking time, backpack capacity, item repair, and bow and arrow crosshairs. Welcome to try it.  -- Translated by Google

## 前言

本人不善于英文表述，本文介绍使用谷歌翻译，不足之处，请见谅。

本模组是个人在游玩过程中，根据自己需求，研究融合而成。

本模组基于最新版本制作，遵循MIT协议，实现方式力求简洁清楚，欢迎有一定经验的朋友个性化修改。


> I am not good at expressing myself in English, so this article uses Google Translate. Please forgive me for any shortcomings.
> This module is a personal research and integration based on my own needs during the game.
> This module is based on the latest version, follows the MIT protocol, and strives to be concise and clear in its implementation. Friends with certain experience are welcome to make personalized modifications.


## 安装方式

文件夹解压后放至在：<KC2_INSTALL_DIR>\Mods\KC2MultiCheats\
> After unzipping the compressed package, put it in: <KC2_INSTALL_DIR>\Mods\KC2MultiCheats\

```
<KC2_INSTALL_DIR>/
└── Mods
    └── KC2MultiCheats
        ├── Data
        │   └── KC2MultiCheats.pak
        ├── mod.cfg
        ├── mod.manifest
        └── README.md
```


## 功能说明

格式说明: 最大攻击速度增益(0.2~0.25 -> 2.0) 表示 原版数值为0.2或0.25，MOD调整为2.0

一、快速升级：训犬技能中救星perk新增buff，获得经验增益100倍(buff_params="xpm*100")
二、攻击速度：最大攻击速度增益(0.2~0.25 -> 2.0)，敌我敏捷差速度增益(0.1 -> 0.2)，敌我技能差增益速度(0.05 -> 0.2)
三、耐力消耗：瞄准(弓20/弩8/枪5)，基础攻击(26)、闪避(20)、跳跃(9)、冲刺(3.5)、耐力伤害(8) -> 全部调整为0.1
四、格挡窗口：玩家大师反时间窗口(0.8 -> 1.0)，玩家完美格挡时间窗口(0.85 -> 1.2)
五、背包容量：扩展8倍(70 -> 560)
六、物品修复：修复工具容量扩展5倍(600 -> 3000)
七、弓箭准星：开启


> Format description: Maximum attack speed gain (0.2~0.25 -> 2.0) means the original value is 0.2 or 0.25, and the MOD is adjusted to 2.0
> 
> 1. Fast upgrade: Add a new buff to the LifeSaver perk in the Dog Training skill, gaining 100 times the experience gain (buff_params="xpm*100")
> 2. Attack speed: Maximum attack speed gain (0.2~0.25 -> 2.0), enemy and friend agility difference speed gain (0.1 -> 0.2), enemy and friend skill difference gain speed (0.05 -> 0.2)
> 3. Stamina consumption: aiming (bow 20/crossbow 8/gun 5), basic attack (26), dodge (20), jump (9), sprint (3.5), stamina damage (8) -> all adjusted to 0.1
> 4. Block window: Player master anti-time window (0.8 -> 1.0), player perfect blocking time window (0.85 -> 1.2)
> 5. Backpack capacity: expanded 8 times (70 -> 560)
> 6. Item repair: repair tool capacity expanded 5 times (600 -> 3000)
> 7. Bow crosshair: open

## 附录一、MOD制作方式

1. pak文件解压：通过7-zip解压
2. pak文件压缩：通过7-zip以zip格式压缩，重命名为pak后缀
3. pak内部文件命名要求：<table_name>__<mod_name>.xml

4. 特别注意: KC2的pak文件不能包含时间戳（这点与KC1不同），推荐下面两种方式
    1. 使用工具[KCD PAK Builder](https://www.nexusmods.com/kingdomcomedeliverance2/mods/78)
    2. 使用7-zip命令行，-mtm=off 禁用修改时间：`7z a -tzip KC2MultiCheats.pak Libs -r -mtm=off`

> 1. pak file decompression: decompress through 7-zip
> 2. pak file compression: compress in zip format through 7-zip, rename to pak suffix
> 3. pak internal file naming requirements: <table_name>__<mod_name>.xml
> 
> 4. Special note: KC2's pak file cannot contain timestamps (this is different from KC1), the following two methods are recommended
>    1. Use the tool [KCD PAK Builder](https://www.nexusmods.com/kingdomcomedeliverance2/mods/78), this method is highly recommended
>    2. Use the 7-zip command line, -mtm=off to disable modification time, for example: `7z a -tzip KC2MultiCheats.pak Libs -r -mtm=off`

## 附录二、我的其它MOD，欢迎试用

- [【天国：拯救2】 KC2 Multi Cheats](https://www.nexusmods.com/kingdomcomedeliverance2/mods/402)
- [【天国：拯救】 KC Multi Cheats](https://www.nexusmods.com/kingdomcomedeliverance/mods/1763)
- [【骑马与砍杀2】 MB2 Multi Cheats](https://www.nexusmods.com/mountandblade2bannerlord/mods/7470)

## 致谢

- [重要工具 - KCD PAK Builder](https://www.nexusmods.com/kingdomcomedeliverance2/mods/78)
- [重要参考 - 【天国：拯救2】原版参数查询 rpg-parameters](https://wiki.fireundubh.com/kingdomcome2/rpg-parameters)
- [重要参考 - 【天国：拯救】原版参数查询 rpg-parameters](https://wiki.fireundubh.com/kingdomcome/rpg-parameters)
- [重要参考 - Slower Leveling](https://www.nexusmods.com/kingdomcomedeliverance2/mods/324)
